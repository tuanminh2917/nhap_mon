// Handle delete by ID
document.getElementById('deleteByIdForm').addEventListener('submit', function (e) {
    e.preventDefault();
    const id = document.getElementById('deleteId').value;
    fetch('/api/delete', {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id }),
    })
        .then(response => response.json())
        .then(data => alert(data.message))
        .catch(error => console.error('Error:', error));
});

// Handle delete by Title
document.getElementById('deleteByTitleForm').addEventListener('submit', function (e) {
    e.preventDefault();
    const title = document.getElementById('deleteTitle').value;
    fetch('/api/delete', {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ title }),
    })
        .then(response => response.json())
        .then(data => alert(data.message))
        .catch(error => console.error('Error:', error));
});
