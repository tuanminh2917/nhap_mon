document.getElementById("signUpForm").addEventListener("submit", async (event) => {
    event.preventDefault();
  
    const username = document.getElementById("username").value;
    const password = document.getElementById("password").value;
    const name = document.getElementById("name").value;
    const dob = document.getElementById("dob").value;
  
    const response = await fetch("/api/common/sign-up", {

        // ấn định phương thức HTTP Request để liên lạc với server, ở đây là POST
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({ username, password, name, dob })
    });
  
    const result = await response.json();
    alert(result.message);

    // Trả về trang chính (localhost:3000)
    window.location.href = '/';
});
  