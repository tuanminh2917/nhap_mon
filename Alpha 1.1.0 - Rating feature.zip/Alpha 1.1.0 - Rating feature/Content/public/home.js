// home.js

document.addEventListener("DOMContentLoaded", function () {
    // Quy ước: (1:Admin, 2:Member, 3:Guest)
    let userRoleId = localStorage.getItem('userRoleId') || '3';
    let loggedUserName = localStorage.getItem('loggedUserName') || 'Guest';

    // Tải header
    fetch('views/common/header.html')
        .then(response => response.text())
        .then(data => {
            document.getElementById('header-container').innerHTML = data;
        })
        .catch(error => {
            console.error('Error loading header:', error);
        });

    // Tải footer
    fetch('views/common/footer.html')
        .then(response => response.text())
        .then(data => {
            document.getElementById('footer-container').innerHTML = data;
        })
        .catch(error => {
            console.error('Error loading footer:', error);
        });

    // Tải signature-part dựa trên vai trò người dùng
    if (userRoleId === '1') displayAdminContent(loggedUserName);
    else if (userRoleId === '2') displayMemberContent(loggedUserName);
    else if (userRoleId === '3') displayGuestContent();
    else {
        document.getElementById('signature-part').innerHTML = '<p>Error loading content. Unknown role.</p>';
    }

    function displayAdminContent(loggedUserName) {
        console.log('Loading admin content...');
        const signaturePart = document.getElementById('signature-part');
        if (signaturePart) {
            signaturePart.innerHTML = `
                <h2>Admin Dashboard</h2>
                <p>Welcome, ${loggedUserName}!</p>
                <button id="addContents">Add Contents</button>
                <button id="updateContents">Update Contents</button>
                <button id="deleteContents">Delete Contents</button>
                <button id="signOut">Sign Out</button>
            `;
    
            document.getElementById('addContents').addEventListener('click', () => {
                window.location.href = 'views/admin/add-contents2.html';
            });
    
            document.getElementById('updateContents').addEventListener('click', () => {
                window.location.href = 'views/admin/update-contents.html';
            });
    
            document.getElementById('deleteContents').addEventListener('click', () => {
                window.location.href = 'views/admin/delete-content.html';
            });
            document.getElementById('signOut').addEventListener('click', () => {
                localStorage.clear();
                alert('Sign Out successfully');
                window.location.href = '/';
            });
        }
    }
    
    function displayMemberContent(loggedUserName) {
        console.log('Loading member content...');
        const signaturePart = document.getElementById('signature-part');
        if (signaturePart) {
            signaturePart.innerHTML = `
                <h2>Member Home</h2>
                <p>Welcome, ${loggedUserName}!</p>
                <button id="signOut">Sign Out</button>
            `;
            document.getElementById('signOut').addEventListener('click', () => {
                localStorage.clear();
                alert('Sign Out successfully');
                window.location.href = '/';
            });
        }
    }
    
    function displayGuestContent() {
        console.log('Loading guest content...');
        const signaturePart = document.getElementById('signature-part');
        if (signaturePart) {
            signaturePart.innerHTML = `
                <h2>Guest Content</h2>
                <p>Welcome to the guest page.</p>
                <button id="signUp">Sign Up</button>
                <button id="signIn">Sign In</button>
            `;
    
            document.getElementById('signUp').addEventListener('click', () => {
                window.location.href = '/views/common/sign-up.html'; // views/common/sign-up.html
            });
    
            document.getElementById('signIn').addEventListener('click', () => {
                window.location.href = '/views/member/sign-in.html'; // views/member/sign-in.html
            });
        }
    }

    const searchInput = document.getElementById('searchInput');
    const searchButton = document.getElementById('searchButton'); // Nút "Gửi"
    const videoContainer = document.getElementById('videoContainer');
    const imageContainer = document.getElementById('imageContainer');

    // drop-down
    const genreFilterInput = document.getElementById('genreFilter');
    const genreFilterButton = document.getElementById('genreFilterButton');

    // Hàm hiển thị lỗi
    function showError(container, message) {
        container.innerHTML = `<p class="error">${message}</p>`;
    }

    // Hàm để gọi API và hiển thị dữ liệu
    function fetchData(url, container, type) {
        fetch(url)
            .then(response => {
                if (!response.ok) throw new Error(`HTTP error: ${response.status}`);
                return response.json();
            })
            .then(data => {
                container.innerHTML = ''; // Xóa nội dung cũ
    
                if (data.length === 0) {
                    showError(container, `No ${type} found.`);
                    return;
                }
    
                // Hiển thị nội dung
                data.forEach(item => {
                    const element = document.createElement('div');
                    /*'classList' là công cụ quản lý các class CSS của JS */
                    // dưới đây sử dụng phương thức .add() của 'classList' 
                    // với mục đích thêm các thuộc tính của class CSS 'item' cho 'element' 
                    element.classList.add('item');
    
                    if (type === 'video') {
                        element.innerHTML = `
                            <h3 class="title">${item.title}</h3>
                            <iframe 
                                width="560" 
                                height="315" 
                                src="${item.src}" 
                                title="${item.title}" 
                                frameborder="0" 
                                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" 
                                allowfullscreen>
                            </iframe>
                            <a href="${item.download_link}" class="download-btn" download>Download</a>
                            <h5>${item.average_rating} / 5</h5> 
                        `;
                        // bổ sung thêm một thẻ <script> vào đoạn innerHTML trên để
                        // khi nhấn vào tiêu đề, một tab mới hiện ra ghi thông tin chi tiết về video (bao gồm cả nút download).
                        // có thể tuỳ biến lại cho phù hợp, ví dụ tạo một tag có id là 'item.id' để sử dụng 'document.getElementById()'
                        element.addEventListener('click', (event) => {
                            if (event.target.classList.contains('title')) {
                                openVideoTab(item)
                            }
                        });

                    } else if (type === 'image') {
                        element.innerHTML = `
                            <h3 class= "title">${item.title}</h3>
                            <img src="${item.src}" alt="${item.title}" />
                            <a href="${item.download_link}" class="download-btn" download>Download</a>
                            <h5>${item.average_rating} / 5</h5> 
                        `;
                        // bổ sung thêm một thẻ <script> vào đoạn innerHTML trên để
                        // khi nhấn vào tiêu đề, một tab mới hiện ra ghi thông tin chi tiết về hình ảnh (bao gồm cả nút download).
                        // có thể tuỳ biến lại cho phù hợp, ví dụ tạo một tag có id là 'item.id' để sử dụng 'document.getElementById()'
                        element.addEventListener('click', (event) => {
                            if (event.target.classList.contains('title')) {
                                openImageTab(item)
                            }
                        });
                    }
                    container.appendChild(element);
                });
            })
            .catch(error => showError(container, `Error: ${error.message}`));
    }

    // Lấy tất cả video và hình ảnh khi mới tải trang
    fetchData('/api/videos', videoContainer, 'video');
    fetchData('/api/images', imageContainer, 'image');

    // Hàm xử lý tìm kiếm
    function handleSearchName() {
        const filterValue = searchInput.value.trim();
        const videoUrl = filterValue ? `/api/videos?value=${filterValue}` : '/api/videos';
        const imageUrl = filterValue ? `/api/images?value=${filterValue}` : '/api/images';

        fetchData(videoUrl, videoContainer, 'video');
        fetchData(imageUrl, imageContainer, 'image');
    }

    /* Thêm hàm mới và sự kiện mới để gửi và lấy dữ liệu qua url đối với drop-down */

    function handleSearchGenre(){
        const filterValue = genreFilterInput.value.trim();
        console.log(filterValue);
        
        const videoUrl = (filterValue !== 'all') ? `/api/videos/genreFillter?value=${filterValue}` : '/api/videos';
        const imageUrl = (filterValue !== 'all') ? `/api/images/genreFillter?value=${filterValue}` : '/api/images';

        fetchData(videoUrl, videoContainer, 'video');
        fetchData(imageUrl, imageContainer, 'image');
    }


    // Thêm sự kiện nút "Gửi"
    searchButton.addEventListener('click', handleSearchName);
    genreFilterButton.addEventListener('click', handleSearchGenre);

    function openVideoTab(item) {
        // Mở một tab mới
        const dynamicTab = window.open('', '_blank');
    
        // Viết nội dung HTML vào tab mới
        dynamicTab.document.write(`
            <!DOCTYPE html>
            <html lang="en">
            <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Dynamic Page</title>
            <style>
                body {
                    font-family: Arial, sans-serif;
                    background-color: #f0f0f0;
                    text-align: center;
                    padding: 20px;
                }
                h3 { color: black; }
                p { font-size: 12px; }
                select {
                    padding: 10px;
                    border-radius: 5px;
                    border: 1px solid #ccc;
                    font-size: 16px;
                    background-color: #fff;
                    width: 150px;
                    cursor: pointer;
                    margin: 10px 0;
                    transition: all 0.3s;
                }
                select:focus {
                    outline: none;
                    border-color: #007BFF;
                    box-shadow: 0 0 5px rgba(0, 123, 255, 0.5);
                }
                button {
                    padding: 10px 20px;
                    font-size: 16px;
                    border: none;
                    border-radius: 5px;
                    background-color: #007BFF;
                    color: white;
                    cursor: pointer;
                    transition: background-color 0.3s, transform 0.2s;
                }
                button:hover {
                    background-color: #0056b3;
                    transform: scale(1.05);
                }
                button:active {
                    background-color: #004080;
                    transform: scale(0.95);
                }
            </style>
            </head>
            <body>
                <h3>${item.title}</h3>
                <iframe 
                    width="560" 
                    height="315" 
                    src="${item.src}" 
                    title="${item.title}" 
                    frameborder="0" 
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" 
                    allowfullscreen>
                </iframe>
                <a href="${item.download_link}" class="download-btn" download>Download</a>
                <hr>
                <p>
                    video_id: ${item.id}<br>
                    title: ${item.title}<br>
                    storage: ${item.storage}<br>
                    src: ${item.src}<br>
                    movie_genre: ${item.movie_genre}<br>
                    format: ${item.format} <br>
                    download_link: ${item.download_link} <br>
                    upload_date: ${item.upload_date} <br>
                    video_style: ${item.video_style} <br>
                    duration: ${item.duration}<br>
                    Rating: ${item.average_rating} / 5<br>
                </p>
                <h5>Rate yourself: </h5>
                <select id="dropdown">
                    <option value="0">0</option>
                    <option value="1">1</option>
                    <option value="2">2</option>
                    <option value="3">3</option>
                    <option value="4">4</option>
                    <option value="5">5</option>
                </select>
                <button id="alertButton">Send</button>
            </body>
            </html>
        `);
    
        dynamicTab.document.close();
    
        // Đăng ký sự kiện
        dynamicTab.onload = () => {
            const alertButton = dynamicTab.document.getElementById('alertButton');
            const dropdown = dynamicTab.document.getElementById('dropdown');
    
            if (alertButton && dropdown) {
                alertButton.addEventListener('click', () => {
                    const userRoleId = parseInt(localStorage.getItem('userRoleId'));
                    const loggedUserId = localStorage.getItem('loggedUserId');
                    const ratingValue = parseInt(dropdown.value);
    
                    if (!loggedUserId || (userRoleId !== 1 && userRoleId !== 2)) {
                        dynamicTab.alert('You need to log in as a user with the correct role to rate this video.');
                        return;
                    }
    
                    const payload = {
                        video_id: item.id,
                        user_id: loggedUserId,
                        point: ratingValue
                    };
    
                    // Gửi yêu cầu POST tới server
                    fetch('/api/member/RateVideo', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify(payload)
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.error) {
                            dynamicTab.alert(`Error: ${data.error}`);
                        } else {
                            dynamicTab.alert(`Success: ${data.message}`);
                        }
                    })
                    .catch(error => {
                        console.error('Error:', error);
                        dynamicTab.alert('An error occurred while sending your rating.');
                    });
                });
            }
        };
    }
    
    

    function openImageTab(item) {
        // Mở một tab mới
        const dynamicTab = window.open('', '_blank');

        // Viết nội dung HTML cơ bản vào tab mới
        dynamicTab.document.write(`
            <!DOCTYPE html>
            <html lang="en">
            <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Dynamic Page</title>
            <style>
                body {
                font-family: Arial, sans-serif;
                background-color: #f0f0f0;
                text-align: center;
                padding: 20px;
                }
                h3 { color: black; }
                p { font-size: 12px; }
                select {
                    padding: 10px;
                    border-radius: 5px;
                    border: 1px solid #ccc;
                    font-size: 16px;
                    background-color: #fff;
                    width: 150px;
                    cursor: pointer;
                    margin: 10px 0;
                    transition: all 0.3s;
                }
                select:focus {
                    outline: none;
                    border-color: #007BFF;
                    box-shadow: 0 0 5px rgba(0, 123, 255, 0.5);
                }
                button {
                    padding: 10px 20px;
                    font-size: 16px;
                    border: none;
                    border-radius: 5px;
                    background-color: #007BFF;
                    color: white;
                    cursor: pointer;
                    transition: background-color 0.3s, transform 0.2s;
                }
                button:hover {
                    background-color: #0056b3;
                    transform: scale(1.05);
                }
                button:active {
                    background-color: #004080;
                    transform: scale(0.95);
                }
            </style>
            </head>
            <body>
                <h3>${item.title}</h3>
                <img src="${item.src}" alt="${item.title}" />
                <a href="${item.download_link}" class="download-btn" download>Download</a>
                <hr>
                <p>
                    image_id: ${item.id}<br>
                    title: ${item.title}<br>
                    storage: ${item.storage}<br>
                    src: ${item.src}<br>
                    movie_genre: ${item.movie_genre}<br>
                    format: ${item.format} <br>
                    download_link: ${item.download_link} <br>
                    upload_date: ${item.upload_date} <br>
                    image_style: ${item.image_style} <br>
                    width: ${item.width} <br>
                    height: ${item.height} <br>
                    Rating: ${item.average_rating} / 5<br>
                </p>
                <h5>Rate yourself: </h5>
                <select id="dropdown">
                    <option value="0">0</option>
                    <option value="1">1</option>
                    <option value="2">2</option>
                    <option value="3">3</option>
                    <option value="4">4</option>
                    <option value="5">5</option>
                </select>
                <button id="alertButton">Send</button>
            </body>
            </html>
        `);

        // Đóng document để hoàn tất việc ghi nội dung
        dynamicTab.document.close();
    
        // Đăng ký sự kiện
        dynamicTab.onload = () => {
            const alertButton = dynamicTab.document.getElementById('alertButton');
            const dropdown = dynamicTab.document.getElementById('dropdown');
    
            if (alertButton && dropdown) {
                alertButton.addEventListener('click', () => {
                    const userRoleId = parseInt(localStorage.getItem('userRoleId'));
                    const loggedUserId = localStorage.getItem('loggedUserId');
                    const ratingValue = parseInt(dropdown.value);
    
                    if (!loggedUserId || (userRoleId !== 1 && userRoleId !== 2)) {
                        dynamicTab.alert('You need to log in as a user with the correct role to rate this video.');
                        return;
                    }
    
                    const payload = {
                        image_id: item.id,
                        user_id: loggedUserId,
                        point: ratingValue
                    };
    
                    // Gửi yêu cầu POST tới server
                    fetch('/api/member/RateImage', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify(payload)
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.error) {
                            dynamicTab.alert(`Error: ${data.error}`);
                        } else {
                            dynamicTab.alert(`Success: ${data.message}`);
                        }
                    })
                    .catch(error => {
                        console.error('Error:', error);
                        dynamicTab.alert('An error occurred while sending your rating.');
                    });
                });
            }
        };
    }
});