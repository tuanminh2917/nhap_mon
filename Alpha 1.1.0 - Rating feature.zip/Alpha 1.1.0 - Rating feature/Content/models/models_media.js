// models_media.js

class Media {
  constructor(id, title, storage, src, movie_genre, format, download_link, upload_date) {
    this.id = id; // not null
    this.title = title; // not null
    this.storage = storage; // not null
    this.src = src; // not null
    this.movie_genre = movie_genre; // not null
    this.format = format; // nullable
    this.download_link = download_link; // nullable
    this.upload_date = upload_date; // nullable
  }

  // Phương thức hiển thị thông tin cơ bản
  displayInfo() {
    console.log(`Title: ${this.title}`);
    console.log(`Storage: ${this.storage}`);
    console.log(`Source: ${this.src}`);
    console.log(`Genre: ${this.movie_genre}`);
    console.log(`Format: ${this.format}`);
    console.log(`Download Link: ${this.download_link}`);
    console.log(`Upload Date: ${this.upload_date}`);
  }
}

  
class Video extends Media {
  constructor(id, title, storage, src, movie_genre, video_style, duration, format, download_link, upload_date) {
    super(id, title, storage, src, movie_genre, format, download_link, upload_date);
    this.video_style = video_style; // Phong cách của video, tên riêng biệt // not null
    this.duration = duration;       // Thời lượng video // nullable
  }

  // Phương thức hiển thị thông tin cho video
  displayInfo() {
    super.displayInfo(); // Gọi phương thức của lớp cha
    console.log(`Style: ${this.video_style}`);
    console.log(`Duration: ${this.duration} seconds`);
  }
}
  
class Image extends Media {
  constructor(id, title, storage, src, movie_genre, image_style, width, height, format, download_link, upload_date) {
    super(id, title, storage, src, movie_genre, format, download_link, upload_date);
    this.image_style = image_style; // Phong cách của hình ảnh, tên riêng biệt // not null
    this.width = width;             // Chiều rộng của ảnh // nullable
    this.height = height;           // Chiều cao của ảnh // nullable
  }

  // Phương thức hiển thị thông tin cho hình ảnh
  displayInfo() {
    super.displayInfo(); // Gọi phương thức của lớp cha
    console.log(`Style: ${this.image_style}`);
    console.log(`Dimensions: ${this.width}x${this.height} pixels`);
  }
}
  
module.exports = { Video, Image };
  