// sign-in.js
document.addEventListener('DOMContentLoaded', () => {
    const signInForm = document.getElementById('signin-form');

    signInForm.addEventListener('submit', async (e) => {
        e.preventDefault(); // Ngăn reload trang

        // Thu thập dữ liệu từ form
        const username = document.getElementById('signin-username').value.trim();
        const password = document.getElementById('signin-password').value.trim();

        if (!username || !password) {
            alert('Please enter both username and password.');
            return;
        }

        try {
            // Gửi yêu cầu GET đến endpoint sign-in
            const response = await fetch(`/api/common/sign-in?username=${encodeURIComponent(username)}&password=${encodeURIComponent(password)}`);
            const result = await response.json();

            if (response.ok) {
                // Lưu vai trò và thông tin người dùng vào localStorage
                localStorage.setItem('userRoleId', result.user.user_role_id); // Lấy 'user_role_id' từ 'result.user'
                localStorage.setItem('loggedUserName', result.user.username); // Lấy 'username' từ 'result.user'

                alert(result.message); // Hiển thị thông báo đăng nhập thành công
                console.log(`User Role ID (1:Admin, 2:Member, 3:Guest): ${localStorage.getItem('userRoleId')}`); // Kiểm tra vai trò trong console
                console.log('loggedUserName: ', localStorage.getItem('loggedUserName'));

                // Trả về trang chính (localhost:3000)
                window.location.href = '/';
            } else {
                // Hiển thị lỗi nếu đăng nhập thất bại
                alert(result.message);
            }
        } catch (err) {
            console.error('Error during sign-in:', err);
            alert('An error occurred while signing in. Please try again.');
        }
    });
});
