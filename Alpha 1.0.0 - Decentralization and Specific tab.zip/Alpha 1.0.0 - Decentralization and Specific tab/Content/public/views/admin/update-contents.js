// Xử lý form Update Video
if (document.querySelector('#update-videos-form')) {
    const updateVideosForm = document.querySelector('#update-videos-form');

    updateVideosForm.addEventListener('submit', async (e) => {
        e.preventDefault(); // Ngăn reload trang

        const formData = new FormData(updateVideosForm); // Thu thập dữ liệu từ form
        const videoData = Object.fromEntries(formData.entries()); // Chuyển đổi thành object

        /*
            Lưu ý: với hai dòng trên, object thu được từ dữ liệu form có các thuộc tính có TÊN (KHÔNG PHẢI GIÁ TRỊ thuộc tính) 
            trùng với GIÁ TRỊ thuộc tính 'name' tại form.
        */

        for (let key in videoData) {
            // Loại bỏ khoảng trắng hai đầu
            videoData[key] = videoData[key].trim();

            // Gán null nếu thuộc tính rỗng
            if (videoData[key] === '') {
                videoData[key] = null;
            }

            //Type casting 'id'
            if (key === 'id' && videoData[key] !== null) {
                videoData[key] = Number(videoData[key]);
                if (isNaN(videoData[key])) {
                    alert('Invalid id value');
                    return;
                }
            }


            // Ép kiểu `duration` về Number
            if (key === 'duration' && videoData[key] !== null) {
                videoData[key] = Number(videoData[key]);
                if (isNaN(videoData[key])) {
                    alert('Invalid duration value');
                    return;
                }
            }
        }

        console.log('Video Data (JSON):', JSON.stringify(videoData));

        try {
            // Gửi yêu cầu đến server
            const response = await fetch('/api/admin/UpdateVideo', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(videoData),
            });

            const result = await response.json(); // Phân tích kết quả

            if (response.ok) {
                alert(result.message); // Thông báo thành công
                updateVideosForm.reset(); // Reset form sau khi thêm thành công
            } else {
                alert(`Error: ${result.error}`); // Thông báo lỗi từ server
                console.error(result.details);
            }
        } catch (err) {
            console.error('Update Video Error:', err);
            alert('An error occurred while updateing the video.');
        }
    });
}

// Xử lý form Update Image
if (document.querySelector('#update-images-form')) {
    const updateImagesForm = document.querySelector('#update-images-form');

    updateImagesForm.addEventListener('submit', async (e) => {
        e.preventDefault(); // Ngăn reload trang

        const formData = new FormData(updateImagesForm); // Thu thập dữ liệu từ form
        const imageData = Object.fromEntries(formData.entries()); // Chuyển đổi thành object

        /*
            Lưu ý: với hai dòng trên, object thu được từ dữ liệu form có các thuộc tính có TÊN (KHÔNG PHẢI GIÁ TRỊ thuộc tính) 
            trùng với GIÁ TRỊ thuộc tính 'name' tại form.
        */


        for (let key in imageData) {
            // Loại bỏ khoảng trắng hai đầu
            imageData[key] = imageData[key].trim();

            // Gán null nếu thuộc tính rỗng
            if (imageData[key] === '') {
                imageData[key] = null;
            }

            //Type casting 'id'
            if (key === 'id' && imageData[key] !== null) {
                imageData[key] = Number(imageData[key]);
                if (isNaN(imageData[key])) {
                    alert('Invalid id value');
                    return;
                }
            }

            // Ép kiểu `width` và `height` về Number
            if ((key === 'width' || key === 'height') && imageData[key] !== null) {
                imageData[key] = Number(imageData[key]);
                if (isNaN(imageData[key])) {
                    alert(`Invalid ${key} value`);
                    return;
                }
            }
        }

        console.log('Image Data (JSON):', JSON.stringify(imageData));

        try {
            // Gửi yêu cầu đến server
            const response = await fetch('/api/admin/UpdateImage', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(imageData),
            });

            const result = await response.json(); // Phân tích kết quả
            if (response.ok) {
                alert(result.message); // Thông báo thành công
                updateImagesForm.reset(); // Reset form sau khi thêm thành công
            } else {
                alert(`Error: ${result.error}`); // Thông báo lỗi từ server
                console.error(result.details);
            }
        } catch (err) {
            console.error('Update Image Error:', err);
            alert('An error occurred while updateing the image.');
        }
    });
}
