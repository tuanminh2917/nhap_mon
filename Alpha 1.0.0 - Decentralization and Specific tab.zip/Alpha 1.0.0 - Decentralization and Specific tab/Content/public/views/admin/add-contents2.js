// Xử lý form Add Video
if (document.querySelector('#add-videos-form')) {
    const addVideosForm = document.querySelector('#add-videos-form');

    addVideosForm.addEventListener('submit', async (e) => {
        e.preventDefault(); // Ngăn reload trang

        const formData = new FormData(addVideosForm); // Thu thập dữ liệu từ form
        const videoData = Object.fromEntries(formData.entries()); // Chuyển đổi thành object

        /*
            Lưu ý: với hai dòng trên, object thu được từ dữ liệu form có các thuộc tính có TÊN (KHÔNG PHẢI GIÁ TRỊ thuộc tính) 
            trùng với GIÁ TRỊ thuộc tính 'name' tại form.
        */

        for (let key in videoData) {
            // Loại bỏ khoảng trắng hai đầu
            videoData[key] = videoData[key].trim();

            // Gán null nếu thuộc tính rỗng
            if (videoData[key] === '') {
                videoData[key] = null;
            }

            // Ép kiểu `duration` về Number
            if (key === 'duration' && videoData[key] !== null) {
                videoData[key] = Number(videoData[key]);
                if (isNaN(videoData[key])) {
                    alert('Invalid duration value');
                    return;
                }
            }
        }

        console.log('Video Data (JSON):', JSON.stringify(videoData));

        try {
            // Gửi yêu cầu đến server
            const response = await fetch('/api/admin/AddVideo', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(videoData),
            });

            const result = await response.json(); // Phân tích kết quả

            if (response.ok) {
                alert(result.message); // Thông báo thành công
                addVideosForm.reset(); // Reset form sau khi thêm thành công
            } else {
                alert(`Error: ${result.error}`); // Thông báo lỗi từ server
                console.error(result.details);
            }
        } catch (err) {
            console.error('Add Video Error:', err);
            alert('An error occurred while adding the video.');
        }
    });
}

// Xử lý form Add Image
if (document.querySelector('#add-images-form')) {
    const addImagesForm = document.querySelector('#add-images-form');

    addImagesForm.addEventListener('submit', async (e) => {
        e.preventDefault(); // Ngăn reload trang

        const formData = new FormData(addImagesForm); // Thu thập dữ liệu từ form
        const imageData = Object.fromEntries(formData.entries()); // Chuyển đổi thành object

        /*
            Lưu ý: với hai dòng trên, object thu được từ dữ liệu form có các thuộc tính có TÊN (KHÔNG PHẢI GIÁ TRỊ thuộc tính) 
            trùng với GIÁ TRỊ thuộc tính 'name' tại form.
        */


        for (let key in imageData) {
            // Loại bỏ khoảng trắng hai đầu
            imageData[key] = imageData[key].trim();

            // Gán null nếu thuộc tính rỗng
            if (imageData[key] === '') {
                imageData[key] = null;
            }

            // Ép kiểu `width` và `height` về Number
            if ((key === 'width' || key === 'height') && imageData[key] !== null) {
                imageData[key] = Number(imageData[key]);
                if (isNaN(imageData[key])) {
                    alert(`Invalid ${key} value`);
                    return;
                }
            }
        }

        console.log('Image Data (JSON):', JSON.stringify(imageData));

        try {
            // Gửi yêu cầu đến server
            const response = await fetch('/api/admin/AddImage', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(imageData),
            });

            const result = await response.json(); // Phân tích kết quả
            if (response.ok) {
                alert(result.message); // Thông báo thành công
                addImagesForm.reset(); // Reset form sau khi thêm thành công
            } else {
                alert(`Error: ${result.error}`); // Thông báo lỗi từ server
                console.error(result.details);
            }
        } catch (err) {
            console.error('Add Image Error:', err);
            alert('An error occurred while adding the image.');
        }
    });
}
