// server.js
const express = require('express');
const bcrypt = require('bcrypt');
const bodyParser = require('body-parser');
const path = require('path');
const { addUser, addImageContent, addVideoContent, getUserByUsername, 
      loadAllImages, loadAllVideos, loadImagesByName, loadVideosByName,
      loadImagesByMovieGenre, loadVideosByMovieGenre,
      updateVideoContent, updateImageContent,
      deleteVideoContent, deleteImageContent } = require('./dal/dal');
const { User, User_Role } = require('./models/models_user');
const { Video, Image} = require('./models/models_media');

const app = express();

// Middleware phục vụ file tĩnh
app.use(express.static(path.join(__dirname, 'public')));
// app.use(express.static(path.join(__dirname, 'views')));

// Middleware parse JSON
app.use(bodyParser.json());

// Route trang chủ
app.get('/', (req, res) => {
  // ở đây, URL cho endpoint là '/', 
  // ý muốn nói nếu người dùng truy cập theo tên miền 'http://localhost:3000/'
  // thì sẽ nhận về dữ liệu từ đường dẫn có đuôi là 'public/index.html'
  // Ở đây, thay vì truyền trực tiếp đường dẫn thì sử dụng thư viện path.join để truyền
  res.sendFile(path.join(__dirname, 'public', 'home.html'));
});

// Route trang đăng ký
app.get('/sign-up', (req, res) => {
  // ở đây, URL cho endpoint là '/sign-up', 
  // ý muốn nói nếu người dùng truy cập theo tên miền 'http://localhost:3000/sign-up'
  // thì sẽ nhận về dữ liệu từ đường dẫn có đuôi là 'views/index.html' - tức trang đăng kí
  // Ở đây, thay vì truyền trực tiếp đường dẫn thì sử dụng thư viện path.join để truyền
  res.sendFile(path.join(__dirname, 'public', 'views', 'common', 'sign-up.html'));
});

app.get('/sign-in', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'views', 'member', 'sign-in.html'));
});

app.get('/admin/add-contents', (req, res)=> {
  res.sendFile(path.join(__dirname, 'public', 'views', 'admin', 'add-contents2.html'))
});

// Route xử lý đăng ký
app.post('/api/common/sign-up', (req, res) => {
  // Ở đây, '/api/common/sign-up' cũng là một endpoint, 
  // nhưng nó không được sử dụng để người dùng trực tiếp truy cập nó mà cho các thành phần của ứng dụng truy cập vào
  // Tất nhiên, vẫn có thể truy cập thông qua 'http://localhost:3000/api/common/sign-up' nhưng sẽ không nhận được gì về.
  const { username, password, name, dob } = req.body;

  // Kiểm tra xem tên người dùng đã tồn tại hay chưa
  getUserByUsername(username, (err, existingUser) => {
    if (err) {
      console.error('Database error:', err);
      return res.status(500).json({ message: 'Internal server error.' });
    }

    // Nếu người dùng đã tồn tại, trả về thông báo lỗi
    if (existingUser) {
      return res.status(409).json({ message: 'Username already exists.' }); // HTTP 409 Conflict
    }

    // Tạo người dùng mới nếu không bị trùng tên
    const newUser = new User(username, password, name, dob);
    addUser(newUser, (err) => {
      if (err) {
        console.error('Error adding user:', err);
        return res.status(500).json({ message: 'Error registering user.' });
      }
      return res.status(201).json({ message: 'User registered successfully!' }); // HTTP 201 Created
    });

  });
});

// Route xử lý đăng nhập sử dụng GET
app.get('/api/common/sign-in', (req, res) => {
  // Lấy dữ liệu từ query parameters thay vì req.body
  const { username, password} = req.query;

  // user ở đây đại diện cho một object thuộc class User, xem 'models_user.js'
  getUserByUsername(username, (err, user) => {
    if (err) {
      console.error(err);
      return res.status(500).json({ message: 'Internal server error.' });
    }

    // Kiểm tra nếu không tìm thấy người dùng
    if (!user) {
      return res.status(404).json({ message: 'User not found.' });
    }

    // So sánh mật khẩu nhập vào với mật khẩu đã băm trong database
    if (password !== user.password) {
      return res.status(401).json({ message: 'Invalid password.' });
    }
    
    // Kiểm tra và trả về vai trò người dùng
    const userRole = user.user_role_id; // Giả định user_role_id là 1: Admin, 2: Member, 3: Guest

    if (userRole === 1) {
      res.status(200).json({ message: 'Login successful!', role: 'Admin', user });
    } else {
      res.status(200).json({ message: 'Login successful!', role: 'Member', user });
    }
  });
});

// Route xử lý thêm Video
app.post('/api/admin/AddVideo', (req, res) => {
  console.log('Request received for video'); // Kiểm tra request đã nhận

  try {
    console.log('Processing video');
    // Tạo đối tượng Video từ dữ liệu request body
    const videoContent = new Video(
      null, // ID sẽ được tự động tạo trong database
      req.body.title,
      req.body.storage,
      req.body.src,
      req.body.movie_genre,
      req.body.video_style,
      req.body.duration,
      req.body.format,
      req.body.download_link,
      req.body.upload_date
    );

    // Thêm nội dung video vào database
    addVideoContent(videoContent, /*callback*/(err, results) => {
      if (err) {
        res.status(500).json({ error: 'Failed to add video content', details: err });
      } else {
        res.status(200).json({ message: 'Video content added successfully', data: results });
      }
    });
  } catch (error) {
    res.status(400).json({ error: 'Invalid video data', details: error.message });
  }
});

// Route xử lý thêm Image
app.post('/api/admin/AddImage', (req, res) => {
  console.log('Request received for image'); // Kiểm tra request đã nhận

  try {
    console.log('Processing image');
    // Tạo đối tượng Image từ dữ liệu request body
    const imageContent = new Image(
      null, // ID sẽ được tự động tạo trong database
      req.body.title,
      req.body.storage,
      req.body.src,
      req.body.movie_genre,
      req.body.image_style,
      req.body.width,
      req.body.height,
      req.body.format,
      req.body.download_link,
      req.body.upload_date
    );

    // Thêm nội dung image vào database
    addImageContent(imageContent, (err, results) => {
      if (err) {
        res.status(500).json({ error: 'Failed to add image content', details: err });
      } else {
        res.status(200).json({ message: 'Image content added successfully', data: results });
      }
    });
  } catch (error) {
    res.status(400).json({ error: 'Invalid image data', details: error.message });
  }
});

// Route xử lý update Video
app.post('/api/admin/UpdateVideo', (req, res) => {
  console.log('Request received for video'); // Kiểm tra request đã nhận

  try {
    console.log('Processing video');
    // Tạo đối tượng Video từ dữ liệu request body
    const videoContent = new Video(
      req.body.id,
      req.body.title,
      req.body.storage,
      req.body.src,
      req.body.movie_genre,
      req.body.video_style,
      req.body.duration,
      req.body.format,
      req.body.download_link,
      req.body.upload_date
    );

    // Thêm nội dung video vào database
    updateVideoContent(videoContent, /*callback*/(err, results) => {
      if (err) {
        res.status(500).json({ error: 'Failed to update video content', details: err });
      } else {
        res.status(200).json({ message: 'Video content updated successfully', data: results });
      }
    });
  } catch (error) {
    res.status(400).json({ error: 'Invalid video data', details: error.message });
  }
});

// Route xử lý update Image
app.post('/api/admin/UpdateImage', (req, res) => {
  console.log('Request received for image'); // Kiểm tra request đã nhận

  try {
    console.log('Processing image');
    // Tạo đối tượng Image từ dữ liệu request body
    const imageContent = new Image(
      req.body.id,
      req.body.title,
      req.body.storage,
      req.body.src,
      req.body.movie_genre,
      req.body.image_style,
      req.body.width,
      req.body.height,
      req.body.format,
      req.body.download_link,
      req.body.upload_date
    );

    // Thêm nội dung image vào database
    updateImageContent(imageContent, (err, results) => {
      if (err) {
        res.status(500).json({ error: 'Failed to update image content', details: err });
      } else {
        res.status(200).json({ message: 'Image content updated successfully', data: results });
      }
    });
  } catch (error) {
    res.status(400).json({ error: 'Invalid image data', details: error.message });
  }
});

// Route xử lý delete Video
app.post('/api/admin/DeleteVideo', (req, res) => {
  console.log('Request received for video'); // Kiểm tra request đã nhận

  try {
    console.log('Processing video');
    // Tạo đối tượng Video từ dữ liệu request body
    const videoContent = { id: req.body.id };

    // Xóa nội dung video từ database
    deleteVideoContent(videoContent, (err, results) => {
      if (err) {
        console.error('Error deleting video:', err);
        return res.status(500).json({ error: 'Failed to delete video content', details: err });
      }

      if (results.affectedRows === 0) {
        // Không có hàng nào bị xóa (ID không tồn tại)
        return res.status(404).json({ error: 'Video ID not found' });
      }

      res.status(200).json({ message: 'Video content deleted successfully', data: results });
    });
  } catch (error) {
    console.error('Invalid video data:', error.message);
    res.status(400).json({ error: 'Invalid video data', details: error.message });
  }
});

// Route xử lý delete Image
app.post('/api/admin/DeleteImage', (req, res) => {
  console.log('Request received for image'); // Kiểm tra request đã nhận

  try {
    console.log('Processing image');
    // Tạo đối tượng Image từ dữ liệu request body
    const imageContent = { id: req.body.id };

    // Xóa nội dung image từ database
    deleteImageContent(imageContent, (err, results) => {
      if (err) {
        console.error('Error deleting image:', err);
        return res.status(500).json({ error: 'Failed to delete image content', details: err });
      }

      if (results.affectedRows === 0) {
        // Không có hàng nào bị xóa (ID không tồn tại)
        return res.status(404).json({ error: 'Image ID not found' });
      }

      res.status(200).json({ message: 'Image content deleted successfully', data: results });
    });
  } catch (error) {
    console.error('Invalid image data:', error.message);
    res.status(400).json({ error: 'Invalid image data', details: error.message });
  }
});

// Video API endpoint
app.get('/api/videos', (req, res) => {
  const filterValue = req.query.value?.trim(); // Loại bỏ khoảng trắng đầu cuối

  const callback = (err, videoSet) => {
      if (err) {
          console.error('Error fetching videos:', err);
          return res.status(500).json({ error: 'Error fetching videos', details: err.message });
      }
      res.json(Array.from(videoSet)); // chuyển đổi Set sang JSON array
  };

  if (!filterValue) {
      loadAllVideos(callback);
  } else {
      loadVideosByName(filterValue, callback);
  }
});

// Image API endpoint
app.get('/api/images', (req, res) => {
  const filterValue = req.query.value?.trim(); // Loại bỏ khoảng trắng đầu cuối

  const callback = (err, imageSet) => {
      if (err) {
          console.error('Error fetching images:', err);
          return res.status(500).json({ error: 'Error fetching images', details: err.message });
      }
      res.json(Array.from(imageSet)); // chuyển đổi Set sang JSON array
  };

  if (!filterValue) {
      loadAllImages(callback);
  } else {
      loadImagesByName(filterValue, callback);
  }
});

// Video API endpoint
app.get('/api/videos/genreFillter', (req, res) => {
  const filterValue = req.query.value?.trim(); // Loại bỏ khoảng trắng đầu cuối

  const callback = (err, videoSet) => {
      if (err) {
          console.error('Error fetching videos:', err);
          return res.status(500).json({ error: 'Error fetching videos', details: err.message });
      }
      res.json(Array.from(videoSet)); // chuyển đổi Set sang JSON array
  };

  loadVideosByMovieGenre(filterValue, callback);
});

// Image API endpoint
app.get('/api/images/genreFillter', (req, res) => {
  const filterValue = req.query.value?.trim(); // Loại bỏ khoảng trắng đầu cuối

  const callback = (err, imageSet) => {
      if (err) {
          console.error('Error fetching images:', err);
          return res.status(500).json({ error: 'Error fetching images', details: err.message });
      }
      res.json(Array.from(imageSet)); // chuyển đổi Set sang JSON array
  };

  loadImagesByMovieGenre(filterValue, callback);

});


// Khởi động server
app.listen(3000, () => {
  console.log('Server running on http://localhost:3000');
});
