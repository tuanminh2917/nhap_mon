// dal/dal.js
const mysql = require('mysql2');
const { User, User_Role } = require('../models/models_user');
const { Video, Image } = require('../models/models_media');
const { get } = require('http');

// Kết nối đến MySQL
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '112358',  // Thay bằng mật khẩu MySQL của bạn
    database: 'media_management2'
});

db.connect((err) => {
  if (err) {
    console.error('Database connection error:', err.message);
  } else {
    console.log('Connected to MySQL.');
  }
});

// Hàm thêm người dùng mới
function addUser(user, callback) {
  const sql = 'INSERT INTO User (username, password, name, dob, user_role_id) VALUES (?, ?, ?, ?, ?)';
  db.query(sql, [user.username, user.password, user.name, user.dob, user.user_role_id], (err, results) => {
      if (err) {
        return callback(err);
      }
      callback(null, results);
  });
}

// Hàm thêm nội dung Video
function addVideoContent(content, callback) {
  const sql = `INSERT INTO Video (title, storage, src, movie_genre, video_style, duration, format, download_link, upload_date) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`;
  db.query(
    sql,
    [
      content.title,
      content.storage,
      content.src,
      content.movie_genre,
      content.video_style,
      content.duration,
      content.format,
      content.download_link,
      content.upload_date
    ],
    (err, results) => {
      if (err) return callback(err);
      callback(null, results);
    }
  );
}

// Hàm thêm nội dung Image
function addImageContent(content, callback) {
  const sql = `INSERT INTO Image (title, storage, src, movie_genre, image_style, width, height, format, download_link, upload_date) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`;
  db.query(
    sql,
    [
      // lấy các thuộc tính của 'content'
      content.title,
      content.storage,
      content.src,
      content.movie_genre,
      content.image_style,
      content.width,
      content.height,
      content.format,
      content.download_link,
      content.upload_date
    ],
    // bắt lỗi và kết quả
    (err, results) => {
      if (err) return callback(err);
      callback(null, results);
    }
  );
}

// Hàm update video
function updateVideoContent(content, callback) {
  const sql0 = 'SELECT video_id FROM video WHERE video_id = ?';
  const sql = `UPDATE video 
               SET title = ?, storage = ?, src = ?, movie_genre = ?, video_style = ?, duration = ?, format = ?, download_link = ?, upload_date = ?
               WHERE video_id = ?`;

  // Kiểm tra ID tồn tại
  db.query(sql0, [content.id], (err, results) => {
    if (err || results.length === 0) {
      return callback(err || 'Video ID not found');
    }

    // Tiến hành cập nhật
    db.query(
      sql,
      [
        content.title,
        content.storage,
        content.src,
        content.movie_genre,
        content.video_style,
        content.duration,
        content.format,
        content.download_link,
        content.upload_date,
        content.id
      ],
      (err, results) => {
        if (err) return callback(err);
        callback(null, results);
      }
    );
  });
}

function updateImageContent(content, callback){
  const sql0 = 'SELECT image_id FROM image WHERE image_id = ?';
  const sql = `UPDATE image 
               SET title = ?, storage = ?, src = ?, movie_genre = ?, image_style = ?, width = ?, height = ?, format = ?, download_link = ?, upload_date = ?
               WHERE image_id = ?`;

  // Kiểm tra ID tồn tại
  db.query(sql0, [content.id], (err, results) => {
    if (err || results.length === 0) {
      return callback(err || 'Image ID not found');
    }

    // Tiến hành cập nhật
    db.query(
      sql,
      [
        // lấy các thuộc tính của 'content'
        content.title,
        content.storage,
        content.src,
        content.movie_genre,
        content.image_style,
        content.width,
        content.height,
        content.format,
        content.download_link,
        content.upload_date,
        content.id
      ],
      (err, results) => {
        if (err) return callback(err);
        callback(null, results);
      }
    );
  });
}

function deleteVideoContent(content, callback) {
  const sql0 = 'SELECT video_id FROM video WHERE video_id = ?';
  const sql = 'DELETE FROM video WHERE video_id = ?';

  // Kiểm tra ID tồn tại
  db.query(sql0, [content.id], (err, results) => {
    if (err) {
      console.error('Error querying video ID:', err);
      return callback(err);
    }
    if (results.length === 0) {
      // Không tìm thấy video ID
      return callback('Video ID not found');
    }

    // Xóa video
    db.query(sql, [content.id], (err, results) => {
      if (err) {
        console.error('Error deleting video:', err);
        return callback(err);
      }
      callback(null, results);
    });
  });
}

function deleteImageContent(content, callback){
  const sql0 = 'SELECT image_id FROM image WHERE image_id = ?';
  const sql = 'DELETE FROM image WHERE image_id = ?';

  // Kiểm tra ID tồn tại
  db.query(sql0, [content.id], (err, results) => {
    if (err) {
      console.error('Error querying image ID:', err);
      return callback(err);
    }
    if (results.length === 0) {
      // Không tìm thấy image ID
      return callback('Image ID not found');
    }

    // Xóa video
    db.query(sql, [content.id], (err, results) => {
      if (err) {
        console.error('Error deleting video:', err);
        return callback(err);
      }
      callback(null, results);
    });
  });
}

// Hàm lấy thông tin người dùng
function getUserByUsername(inputUsername, callback) {
  db.query('SELECT * FROM user WHERE username = ?', [inputUsername], (err, results) => {
    if (err) {
      return callback(err); // Xử lý lỗi
    }
    if (results.length ===/*strictly */ 0) {
      return callback(null, null); // Không tìm thấy người dùng
    }
    callback(null, results[0]); // Trả về kết quả đầu tiên, là một object thuộc class User, xem 'models_user.js'
  });
}

// Load video data
function loadAllVideos(callback/* */) {
  const videoSet = new Set();
  db.query('SELECT * FROM video', (err, results) => {
      if (err) return callback(err);
      results.forEach(row => {
          videoSet.add(new Video(row.video_id, row.title, row.storage, row.src, row.movie_genre, row.video_style, row.duration, row.format, row.download_link, row.upload_date));
      });
      callback(null, videoSet);
  });
}

/*
+ 'SELECT * FROM video': câu lệnh truy vấn mySQL
+ (err, results): 2 biến đại diện cho kết quả trả về:
  err: đại diện cho lỗi
  results: đại diện cho kết quả
+ results.forEach(row => {...}): duyệt kết quả trả về: với mỗi hàng, bỏ vào 'videoSet' theo constructor
+ callback: giải thích sau
*/

// Load image data
function loadAllImages(callback) {
  const imageSet = new Set();
  db.query('SELECT * FROM image', (err, results) => {
      if (err) return callback(err);
      results.forEach(row => {
          imageSet.add(new Image(row.image_id, row.title, row.storage, row.src, row.movie_genre, row.image_style, row.width, row.height, row.format, row.download_link, row.upload_date));
      });
      callback(null, imageSet);
  });
}

/*
Giải thích tương tự trên
*/

function loadVideosByName(value, callback) {
  const videoSet = new Set();
  db.query('SELECT * FROM video WHERE title LIKE ?', [`%${value}%`], (err, results) => {
      if (err) return callback(err);
      results.forEach(row => {
          videoSet.add(new Video(row.video_id, row.title, row.storage, row.src, row.movie_genre, row.video_style, row.duration, row.format, row.download_link, row.upload_date));
      });
      callback(null, videoSet);
  });
}

function loadImagesByName(value, callback) {
  const imageSet = new Set();
  db.query('SELECT * FROM image WHERE title LIKE ?', [`%${value}%`], (err, results) => {
      if (err) return callback(err);
      results.forEach(row => {
          imageSet.add(new Image(row.image_id, row.title, row.storage, row.src, row.movie_genre, row.image_style, row.width, row.height, row.format, row.download_link, row.upload_date));
      });
      callback(null, imageSet);
  });
}

function loadVideosByMovieGenre(value, callback) {
  const videoSet = new Set();
  db.query('SELECT * FROM video WHERE movie_genre LIKE ?', [`%${value}%`], (err, results) => {
      if (err) return callback(err);
      results.forEach(row => {
          videoSet.add(new Video(row.video_id, row.title, row.storage, row.src, row.movie_genre, row.video_style, row.duration, row.format, row.download_link, row.upload_date));
      });
      callback(null, videoSet);
  });
}

function loadImagesByMovieGenre(value, callback) {
  const imageSet = new Set();
  db.query('SELECT * FROM image WHERE movie_genre LIKE ?', [`%${value}%`], (err, results) => {
      if (err) return callback(err);
      results.forEach(row => {
          imageSet.add(new Image(row.image_id, row.title, row.storage, row.src, row.movie_genre, row.image_style, row.width, row.height, row.format, row.download_link, row.upload_date));
      });
      callback(null, imageSet);
  });
}

module.exports = { addUser, addImageContent, addVideoContent, getUserByUsername, 
                  loadAllImages, loadAllVideos, loadImagesByName, loadVideosByName,
                  loadImagesByMovieGenre, loadVideosByMovieGenre,
                  updateVideoContent, updateImageContent,
                  deleteVideoContent, deleteImageContent };
