// models_user.js

class User {
    constructor(username, password, name, dob, user_role_id = 2) {  // role mặc định là Member
        this.username = username;
        this.password = password;
        this.name = name;
        this.dob = dob;
        this.user_role_id = user_role_id;
    }
}

class User_Role {
    constructor(user_role_id, role_name)
    {
        this.user_role_id = user_role_id;
        this.role_name = role_name;
    }
}
  
module.exports =  { User, User_Role };