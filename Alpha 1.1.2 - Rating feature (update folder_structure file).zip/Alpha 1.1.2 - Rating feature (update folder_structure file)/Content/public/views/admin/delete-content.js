// Handle delete by ID for Video
document.getElementById('videoDeleteForm').addEventListener('submit', function (e) {
    e.preventDefault();

    const videoIdInput = document.getElementById('videoId').value.trim();
    if (!videoIdInput || isNaN(videoIdInput) || !Number.isInteger(videoIdInput) || videoIdInput <= 0 ) {
        alert('Invalid Video ID!');
        return;
    }
    const id = Number(videoIdInput);

    console.log('Video Data (JSON):', JSON.stringify({ id }));

    fetch('/api/admin/DeleteVideo', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id }),
    })
        .then(response => response.json())
        .then(data => alert(data.message))
        .catch(error => {
            console.error('Error:', error);
            alert('An error occurred while processing your request.');
        });
});

// Handle delete by Title for Image
document.getElementById('imageDeleteForm').addEventListener('submit', function (e) {
    e.preventDefault();

    const imageIdInput = document.getElementById('imageId').value.trim();
    if (!imageIdInput || isNaN(imageIdInput) || !Number.isInteger(imageIdInput) || imageIdInput <= 0 ) {
        alert('Invalid Image ID!');
        return;
    }
    const id = Number(imageIdInput);

    console.log('Image Data (JSON):', JSON.stringify({ id }));

    fetch('/api/admin/DeleteImage', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id }),
    })
        .then(response => response.json())
        .then(data => alert(data.message))
        .catch(error => {
            console.error('Error:', error);
            alert('An error occurred while processing your request.');
        });
});
